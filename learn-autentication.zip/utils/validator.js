const validateName = (name) => {
  const nameRegex = new RegExp(/[a-zA-Z][a-zA-Z]+[a-zA-Z]$/);
  return nameRegex.test(name);
}

const validateEmail = (email) => {
  const emailRegex = new RegExp(/^[A-Za-z0-9_!#$%&'*+/=?`{|}~^.-]+@[A-Za-z0-9.-]+$/, "gm");

  return emailRegex.test(email);
}

const validatePassword = (password) => {
  const passwordRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*?[a-zA-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$");
    return passwordRegex.test(password);
}

module.exports = {
  validateName,
  validateEmail,
  validatePassword
}